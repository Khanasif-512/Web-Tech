<?php 
include "headrr.php";
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../Website/css/aboutUs.css">
    <title>About Us</title>
</head>
<body>
    <div class="about-us-container">
        <div class="faq">
            <span class="our-story">Our story</span>
            <span class="contact-us">Contact us</span>
            <span class="help-faq">Help and FAQs</span>
            <span class="terms-and-conditions">Terms and Conditions</span>
        </div>

        <div class="line">

        </div>
        
        <div class="about-us-content">
            <div class="about-us">
                <span class="about">
                    About
                </span>
                <span class="us">
                    Us
                </span>
            </div>
            <div class="about-us-text">
                Lorem ipsum dolor sit amet consectetur adipisicing elit. Debitis quas praesentium iste dignissimos explicabo dolore laboriosam optio laborum illo autem, consequatur repellat similique dicta temporibus perferendis ad dolor illum quaerat fugiat vel labore delectus. Tempora distinctio explicabo quaerat illo voluptas ut esse repellat voluptatem recusandae repellendus quo tempore earum mollitia quidem magnam, suscipit commodi sint voluptates minus. Ullam expedita voluptate illum excepturi id tempora, pariatur, similique, quaerat cumque sint veritatis commodi. Eveniet accusamus fugiat facilis inventore cum voluptatum iusto ut mollitia, vitae, ipsum saepe magni placeat quae quibusdam unde porro, provident assumenda expedita error sed perferendis! Similique, sit quisquam aperiam blanditiis doloribus suscipit error nesciunt officia atque, recusandae tempore ad ea amet eaque quod explicabo? In quo deleniti id aliquam cum architecto eos amet ex perspiciatis? Velit animi nobis aliquid rerum quis aliquam, nulla nihil laudantium quisquam voluptatem mollitia perspiciatis ipsam iusto quibusdam, in, praesentium libero deleniti sit accusamus dolor doloremque eveniet unde labore a. Consectetur itaque maxime animi delectus libero similique quas illum rerum ipsum facere repudiandae vero fugit provident sed quidem ex saepe tempore esse, consequuntur tempora. Incidunt vel perspiciatis minus a autem dignissimos, ex voluptas libero maiores nemo. Nisi harum, assumenda ullam architecto dolor sunt aliquam pariatur vitae exercitationem quod debitis! Soluta minus harum rerum iusto. Vel id eaque quis sunt possimus suscipit cupiditate quos aut, molestiae enim, nemo dolor voluptatibus necessitatibus sapiente tempora aliquam voluptatum. Dolor similique vero veritatis expedita illum, laudantium temporibus deleniti repellat magnam quo necessitatibus. Obcaecati, porro doloribus in nesciunt voluptates nulla officiis vero numquam, voluptatem modi quia voluptate! Maxime exercitationem illum illo. Facere hic fuga, blanditiis nobis corporis possimus beatae dolorem accusantium ipsam? Omnis rem assumenda molestias reiciendis voluptatum magni eum laboriosam facilis iure impedit tenetur quae optio, placeat animi excepturi tempora deleniti, et cupiditate provident ipsum eos delectus sequi? Officiis, voluptatem!
            </div>
        </div>
    </div>
</body>
</html>

<?php 
include "footer.php";
?>